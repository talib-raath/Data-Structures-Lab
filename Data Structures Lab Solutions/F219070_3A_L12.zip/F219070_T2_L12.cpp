#include<iostream>
using namespace std;
void heapify(int arr[], int N, int i)
{

    // largest as root
    int largest = i;

    int left = 2 * i + 1;

    int right = 2 * i + 2;

    // if left children is larget then the root
    if (left < N && arr[left] > arr[largest])
        largest = left;

    // If right children is larger than largest,//so far
    if (right < N && arr[right] > arr[largest])
        largest = right;

    // If the largest is not root
    if (largest != i)
    {
        swap(arr[i], arr[largest]);

        heapify(arr, N, largest);
    }
}

// for sorting
void heapSort(int arr[], int N)
{
    for (int i = N / 2 - 1; i >= 0; i--)
        heapify(arr, N, i);

    for (int i = N - 1; i > 0; i--)
    {
        swap(arr[0], arr[i]);

        heapify(arr, i, 0);
    }
}

// print array 
void display(int arr[], int N)
{
    for (int i = 0; i < N; ++i)
        cout << arr[i] << " ";
    cout << "\n";
}

int main()
{
    int *arr,size;
    cout<<"Enter array Size: ";
    cin>>size;
    arr = new int[size];
    cout<<"Enter Elements\n";
    for (int i=0;i<size;i++){
        cin>>arr[i];
    }

    heapSort(arr, size);

    cout << "\nSorted array is \n";
    display(arr, size);
}
