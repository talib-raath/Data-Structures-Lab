#include <iostream>
using namespace std;
class Heap
{
public:
//Attrbutes
    int *arr;      
    int maxsize;   
    int count;     
	//constructir
    Heap(int s) 
    {
        maxsize = s;
        arr = new int(s);
        count = 0;
    }

    // return left child
    int left(int i)
    {
        return (i * 2) + 1;
    }

    // return right child
    int right(int i)
    {
        return (i * 2) + 2;
    }
    // return parent
    int parent(int i)
    {
        return (i - 1) / 2;
    }

    // function to insert element inside heap
    void insert(int val)
    {
        if (count == maxsize)
        {
            cout << "\nOverFlow\n";
            return;
        }
        count++;
        int i = count - 1;
        arr[i] = val;

        while ((i != 0) && arr[parent(i)] > arr[i])
        {
            swap(arr[i], arr[parent(i)]);
            i = parent(i);
        }
    }

    // function to return the minimum element inside the heap
    int get_min()
    {
        return arr[0];
    }

    // function to remove the minimum element inside the heap
    int extract_min()
    {
        if (count <= 0)
        {
            return 0;
        }
        if (count == 1)
        {
            count--;
            return arr[0];
        }
        int root = arr[0];
        arr[0] = arr[count - 1];
        count--;
        return root;
    }

    //dis-lay
    void display()
    {
        for (int i = 0; i < count; i++)
        {
            cout << arr[i] << "  ";
        }
    }

   
};
int main()
{
   int choice;
   int size,elem;
   cout<<"Enter size of Heap: ";
   cin>>size;
   Heap H(size);
       while (1){
        cout << "1-Insert\n2-Extract Min\n3-Get Min\n4-Display\n5-Exit" << endl;
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
			cout<<"Enter Element: ";
			cin>>elem;
			H.insert(elem);
			break;
        case 2:
            cout << "Min Extracted!" << endl;
            cout<<"\nExtracted Min: "<<H.extract_min()<<endl;         //calling function for extraction 
            break;

        case 3:
            cout << "Min Value is: " << H.get_min() << endl;    //displlays minimum value
            break;
        case 4:
            cout << "\nHeap Elements Is: ";
            H.display();     //calling display function 
            break;
        case 5:
            exit(1);
        }
    system("pause");
    system("cls");
    }
}


