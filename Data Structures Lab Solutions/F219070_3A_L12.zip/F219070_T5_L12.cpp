#include <iostream>
using namespace std;

// to heapify a subtree with root at given index
void max_heap(int arr[], int i, int N)
{
    int largest = i;
    int right = 2 * i + 2;
    int left = 2 * i + 1;

    if (left < N && arr[left] > arr[i])
        largest = left;
    if (right < N && arr[right] > arr[largest])
        largest = right;
    if (largest != i)
    {
        swap(arr[i], arr[largest]);
        max_heap(arr, largest, N);
    }
}

// creating max heap
void build_maxHeap(int arr[], int N)
{

    for (int i = (N - 2) / 2; i >= 0; --i)
        max_heap(arr, i, N);
}
//displaying array
void Display(int *Arrr, int size)
{
    for (int i = 0; i < size; ++i)
        cout << Arrr[i] << " ";
}

int main()
{
    int *arr,size;
    cout<<"Enter array Size: ";
    cin>>size;
    arr = new int[size];
    cout<<"Enter Elements\n";
    for (int i=0;i<size;i++){
        cin>>arr[i];
    }
  

    cout << "\nMinimum Array of Heap: ";
    Display(arr, size);

    build_maxHeap(arr, size);

    cout << "\n\nMaximum Array of Heap: ";
    Display(arr, size);
    cout<<endl;
}
