#include <iostream>
using namespace std;

//Date struct
struct Date {
	int day, mon, year;
};
//Node to implement a LL
struct Node {
	string message;
	Node* next;
	Date date;
};


// Making ADT to implement LL
class Queue {
	Node* front;
	Node* rear;
public:
	//MAKING a constructor
	Queue() {
		//Initialising with NULL;
		front = rear = NULL;
	}

	Node* CreateNode(string msg, int d, int m, int y) {
		Node* newNode = new Node;
		newNode->message = msg;
		newNode->date.day = d;
		newNode->date.mon = m;
		newNode->date.year = y;
		newNode->next = NULL;
		return newNode;
	}
	//Making enqueue to put msg in LL
	void enqueue(string msg, int d, int m, int y) {
		Node* newNode = CreateNode(msg, d, m, y);
		if (isEmpty()) {
			rear = front = newNode;
		}
		else {
			//storing in next to next
			rear->next = newNode;
			rear = newNode;
		}
	}
	//dequeuing , deleting node
	void dequeue() {
		Node* temp = front;
		int highest = 0;
		int i = 0;
		while (temp->next != NULL && !isEmpty()) {
			if (temp->date.year < temp->next->date.year)
				highest = i;
			else if (temp->date.mon < temp->next->date.mon)
				highest = i;
			else if (temp->date.day < temp->next->date.day)
				highest = i;
			else if(temp->date.day == temp->date.day && temp->date.mon == temp->date.mon && temp->date.year == temp->date.year) {
				highest = i;
			}
			temp = temp->next;
			i++;
		}

		temp = front;
		i = 0;
		while (i < highest-2) {
			temp = temp->next;
			i++;
		}
		if (!isEmpty()) {
			Node* t = temp->next;
			temp->next = t->next;
			delete t;
			t = NULL;
		}

	}
	//returning the first element
	string Get_Front() {
		return front->message;
	}

	bool isEmpty() {
		if (rear == NULL && front == NULL)
			return true;
		return false;
	}

	void display() {
		Node* temp = front;

		while (temp != NULL) {
			cout << temp->message << endl;
			temp = temp->next;
		}

	}
};

//Driver COde
int main() {
	Queue q;
	q.enqueue("Talib", 1, 1, 2022);
	q.enqueue("Ahmad", 2, 2, 2010);
	q.enqueue("Raath", 3, 3, 2001);
	q.enqueue("Fida", 4, 4, 2012);
	q.enqueue("Fida", 4, 4, 2012);
	cout << "Before Dequeue\n";
	q.display();
	cout << "After Dequeue\n";
	q.dequeue();

	q.display();
}