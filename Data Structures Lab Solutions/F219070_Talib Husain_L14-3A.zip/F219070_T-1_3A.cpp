#include <iostream>
#include <queue>
#include <stack>
using namespace std;

// creating a Node for queue
struct Node
{
    int data;
    Node *next;
};

// Making a Queue ADT
class Queue
{
    Node *front;
    Node *rear;

public:
    // Constructor to initialze with NULL
    Queue()
    {
        front = NULL;
        rear = NULL;
    }

    // Functon to Insert a data in a queue
    void enqueue(int x)
    {

        // Create new node
        Node *temp = new Node;
        temp->data = x;
        temp->next = NULL;
        // new node is front and rear both If queue is empty
        if (rear == NULL)
        {
            front = temp;
            rear = temp;
        }
        else
        {

            // Add the new node at end
            rear->next = temp;
            rear = temp;
        }
    }

    // Function to remove
    int dequeue()
    {
        // If queue is empty, return NULL
        if (front == NULL)
        {
            cout << "Queue is Empty";
            return NULL;
        }
        else
        {

            Node *temp = front;
            front = front->next;
            if (front == NULL)
                rear = NULL;
            int data = temp->data;
            delete temp;
            temp = NULL;
            return data;
        }
    }

    void display()
    {
        Node *temp = front;
        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    bool isEmpty()
    {
        if (front == NULL)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};

// class graph
class Graph
{
    char **arr;
    int count;
    int no_vertex = 0;

public:
    // constructor
    Graph(int no_vertex = 9)
    {
        count = 0;
        this->no_vertex = no_vertex;
        // Dynamically allocating 2-d array

        arr = new char *[no_vertex];

        for (int i = 0; i < no_vertex; i++)
        {
            *(arr + i) = new char[no_vertex];
        }

        // initialising array with 0
        for (int i = 0; i < no_vertex; i++)
        {
            for (int j = 0; j < no_vertex; j++)
            {
                arr[i][j] = '-';
            }
        }
    }

    // Code for addinf vertex
    void Addvertex(char x)
    {
        if (count < no_vertex)
        {
            arr[count][0] = x;
            count++;
        }
        else
            cout << "Vertex can't be added\n";
    }

    // code for adding a connection between two vertex
    void addedge(char vertex1, char vertex2)
    {

        for (int i = 0; i < no_vertex; i++)
        {
            if (arr[i][0] == vertex1)
            {
                for (int j = 0; j < no_vertex; j++)
                {
                    if (arr[i][j] == '-')
                    {
                        arr[i][j] = vertex2;
                        break;
                    }
                }
            }
        }
    }

    // Code for printig
    void print()
    {
        for (int i = 0; i < no_vertex; i++)
        {
            for (int j = 0; j < no_vertex; j++)
            {
                if (arr[i][j] != '-')
                    cout << arr[i][j];
                if (j == 0)
                    cout << ": ";
                else if (arr[i][j] != '-')
                    cout << " -> ";
            }
            cout << "\n";
        }
    }

    // BFS for finding a path
    void BFS(char start, char goal)
    {
        // queue to  mark
        queue<char> q;
        // visit array to mark visited ones
        char visit[256];

        bool x = true;
        q.push(start);
        visit[0] = start;
        bool check = true;
        // Loop while queue is not emty
        while (!q.empty())
        {
            for (int i = 0; i < no_vertex; i++)
            {
                if (arr[i][0] == q.front())
                {
                    check = false;
                    for (int j = 1; j < no_vertex; j++)
                    {
                        if (arr[i][j] != '-')
                        {
                            for (int k = 0; k < no_vertex; k++)
                            {
                                if (visit[k] == arr[i][j])
                                {
                                    x = false;
                                }
                            }
                            if (x)
                            {
                                visit[i] = arr[i][j];
                                q.push(arr[i][j]);
                            }
                            x = true;
                        }
                        else
                            break;
                    }
                }
                if (i == no_vertex || !check)
                {
                    check = true;
                    break;
                }
            }

            cout << q.front() << "->";
            if (q.front() == goal)
                break;
            q.pop();
        }
    }

    // dfs
    void DFS(char start, char goal)
    {
        stack<char> q;
        char visit[256];

        bool x = true;
        q.push(start);
        visit[0] = start;
        bool check = true;
        while (!q.empty())
        {
            cout << q.top() << "->";
            if (q.top() == goal)
                break;
            for (int i = 0; i < no_vertex; i++)
            {
                if (arr[i][0] == q.top())
                {
                    q.pop();
                    check = false;
                    for (int j = 1; j < no_vertex; j++)
                    {
                        if (arr[i][j] != '-')
                        {
                            for (int k = 0; k < no_vertex; k++)
                            {
                                if (visit[k] == arr[i][j])
                                {
                                    x = false;
                                }
                            }
                            if (x)
                            {
                                visit[i] = arr[i][j];
                                q.push(arr[i][j]);
                            }
                            x = true;
                        }
                        else
                            break;
                    }
                }
                if (i == no_vertex || !check)
                {
                    check = true;
                    break;
                }
            }
        }
    }
};

// Driver COde
int main()
{
    Graph g(13);
    // Adding a vertex
    g.Addvertex('a');
    g.Addvertex('b');
    g.Addvertex('c');
    g.Addvertex('d');
    g.Addvertex('e');
    g.Addvertex('f');
    g.Addvertex('g');
    g.Addvertex('h');
    g.Addvertex('i');
    g.Addvertex('j');
    g.Addvertex('k');
    g.Addvertex('l');
    g.Addvertex('m');

    g.addedge('a', 'b');
    g.addedge('a', 'c');
    g.addedge('b', 'd');
    g.addedge('b', 'e');
    g.addedge('c', 'f');
    g.addedge('f', 'j');
    g.addedge('d', 'g');
    g.addedge('d', 'h');
    g.addedge('e', 'i');
    g.addedge('i', 'm');
    g.addedge('g', 'j');
    g.addedge('g', 'l');

    cout << "Adj List Graph\n";
    g.print();
    cout << "\nBFS Path\n";
    cout << "BFS Path from a--->g\n";
    g.BFS('a', 'g');
    cout << "\n\nDFS Path from a--->g\n";
    g.DFS('a', 'g');
}