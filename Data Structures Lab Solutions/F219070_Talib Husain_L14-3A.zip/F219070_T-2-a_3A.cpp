#include <iostream>
using namespace std;

//node for chainng of keys
struct node
{
	int key;
	node *next;
};

//class hashtable 
class HashTable
{
	node **chain;
	int size;

public:
//constructor
	HashTable(int size = 10)
	{
		this->size = size;
		chain = new node *[size];

		for (int i = 0; i < size; i++)
		{
			chain[i] = NULL;
		}
	}

	//hash function for hashing
	int hashFun(int key)
	{
		return key % size;
	}

	//method to inserting keys
	void insert(int key)
	{
		int index = hashFun(key);

		node *newNode = new node;
		newNode->key = key;
		newNode->next = NULL;
		node *temp = chain[index];

		//if first index is NULL set to first
		if (temp == NULL)
		{
			chain[index] = newNode;
			return;
		}

		// move to the end of chained data
		while (temp->next != NULL)
		{
			temp = temp->next;
		}

		temp->next = newNode;
		return;
	}

	// method  to search a key from the chaining
	int search(int key)
	{
		int count = 0;
		node *current;

		//traverse the full data where data matches return
		while (count < size)
		{
			current = chain[count];
			while (current != NULL)
			{
				if (key == current->key)
				{
					cout << "Key is Found\n";
					return count;
				}
				current = current->next;
			}
			count++;
		}

		cout << "Key is not Found\n";
		return -1;
	}

	//method to delete the key
	void Delete(int key)
	{
		int index = search(key);

	//if not foound
		if (index == -1)
		{
			cout << "Key does't exist\n";
			return;
		}
		node *current = chain[index];
		node *prev = NULL;
		//find the key and delete it
		while (current != NULL)
		{
			if (key == current->key)
			{
				break;
			}
			prev = current;
			current = current->next;
		}

		node *temp = current;
		prev->next = temp->next;
		delete temp;

		temp = NULL;
	}

	//mrhtod to display the data
	void Display()
	{
		int count = 0;
		node *current;
		while (count < size)
		{
			current = chain[count];
			cout << count << ": ";
			while (current != NULL)
			{
				cout << current->key;
				current = current->next;
				if (current)
					cout << "->";
			}
			cout << endl;
			count++;
		}
	}
};


//driver code
int main()
{
	HashTable h(5);
	int ch = 0, elem = 0;
	while (true)
	{
		cout << "1-Insert\n2-Delete\n3-Search\n4-Display\n5-Exit\nEnter Choice: ";
		cin >> ch;
		switch (ch)
		{
		case 1:
			cout << "Enter Element: ";
			cin >> elem;
			h.insert(elem);
			break;
		case 2:
			cout << "Enter Element: ";
			cin >> elem;
			h.Delete(elem);
			break;
		case 3:
			cout << "Enter Element: ";
			cin >> elem;
			h.search(elem);
			break;
		case 4:
			h.Display();
			break;
		case 5:
			exit(1);
			break;
		default:
			break;
		}
		system("pause");
		system("cls");
	}
}