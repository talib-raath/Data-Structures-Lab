#include<iostream>

//hash table class
class HashTable{
    int *arr;
    int size = 0;
public:
    //Constructor 
    HashTable(int size = 15){
        this->size = size;
        arr = new int[size];

        for(int i=0;i<size;i++){
            arr[i] = NULL;
        }
    }

    //hash function
    int hash(int key){
        return (key % size);
    }


    //insert function
    void insert(int key){
        int index = hash(key);
        int count = 0;
            //loop till empty cell not found
            while(arr[index]!=NULL){
                index++;
                count++;
                if(index == this->size){
                    index = 0;
                }

                //return if no space left
                if(size<=count){
                    std::cout<<"No space left\n";
                return;
                }
            }

            //inserting a key
        arr[index] = key;
    }

    //method to search
    int search(int key){
        int index = hash(key);
        int count = 0;
        //find the key until key not found
        while (arr[index]!=key && count<= size){
            index++;
            count++;
            if(index == size){
                index = 0;
            }
            //if key not found return -1
            if(hash(key) == index)
            return -1;
        }
        return index;
        

    }

    //Method to found
    void Display(){
        std::cout<<"Hash Table\n";
        for(int i=0;i<size;i++){
            std::cout<<i<<"->"<<arr[i]<<std::endl;
        }
    }

    //method to delete key
    void DeleteKey(int key){
        int index = hash(key);
        int found = index;
        int freespace = index;
        while (arr[index]!=key){
            index++;
            if (index >= size)
                index = 0;
            if(key == arr[index]){
                arr[index] = NULL;
                found = index;
                freespace = index;
                // to check others index are at their pos if not move them to their pos
                for(int i=found; i != found-1;i++){
                    if(i==size)
                      i = 0;

                    if(hash(arr[i])!=i){
                        std::swap(arr[freespace],arr[i]);
                        freespace = i;
                    }
                }
        std::cout<<"Key is Deleted\n";
                return;
            }
        }

        std::cout<<"Key not found\n";
    }
};

//Driver code
int main(){
    HashTable ht(15);
    //inserting keys
    ht.insert(17);
    ht.insert(26);
    ht.insert(15);
    ht.insert(9);
    ht.insert(11);
    ht.insert(43);
    ht.insert(75);
    ht.insert(19);
    ht.insert(35);
    ht.insert(45);
    ht.insert(55);
    ht.insert(9);
    ht.insert(10);
    ht.insert(21);
    ht.insert(61);
    ht.insert(23);
    ht.Display();

    std::cout<<std::endl;
    ht.DeleteKey(10);
    std::cout<<"after deleting"<<std::endl;
    ht.Display();
    std::cout<< ht.search(17)<<std::endl;
}