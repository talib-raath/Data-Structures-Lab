#include<iostream>

//hash table
class HashTable{
    int *arr;
    int size = 0;
    int count = 0;
public:
    //constructor
    HashTable(int size = 15){
        this->size = size;
        arr = new int[size];

        for(int i=0;i<size;i++){
            arr[i] = NULL;
        }
    }
    
    //hash function
    int hash(int key,int i, char op){
        if(op == '+')
        return (key + (i*i))%size;

        return (key - (i*i))%size;
    }

    //method to insert key
    void insert(int key){
        if(count>=size){
            std::cout<<"No space to add\n";
            return;
        }
        int i=0;
        int decide = 0;
        int index = hash(key,i,'+');
    // loop until empty not found
        while (arr[index] != 0){
            decide++;
            if(decide%2==1){
            index = hash(key,i,'-');
            i++;
            }
            else
            index = hash(key,i,'+');
        }
        
        arr[index] = key;
        count++;
    }

    //method to search key
    int search(int key){
        int i =0;
        int decide = 0;
        int index = hash(key,i,'+');
        int terminate = 0;
        //loop till not found
        while (arr[index]!=key && terminate <= size){
            decide++;
            if(decide%2==1){
            index = hash(key,i,'-');
            i++;
            }
            else
            index = hash(key,i,'+');
            terminate++;
        }
        if(arr[index] == key)
        return index;
        return -1;
    }

    //method to display 
    void Display(){
        std::cout<<"Hash Table\n";
        for(int i=0;i<size;i++){
            std::cout<<i<<"->"<<arr[i]<<std::endl;
        }
    }

    //delete key
    void DeleteKey(int key){
        int index = search(key);
        if(index  ==-1){
           std::cout<<"Key not Found\n";
           return;
        }
        std::cout<<"Key is Deleted\n";
        arr[index] = 0;
    }
};

//driver code
int main(){
    HashTable ht(15);
    ht.insert(17);
    ht.insert(26);
    ht.insert(15);
    ht.insert(9);
    ht.insert(11);
    ht.insert(43);
    ht.insert(75);
    ht.insert(19);
    ht.insert(35);
    ht.insert(45);
    ht.insert(55);
    ht.insert(9);
    ht.insert(10);
    ht.insert(21);
    ht.insert(61);
    ht.insert(23);
    ht.Display();
    std::cout<<std::endl;
    ht.DeleteKey(35);
    std::cout<<"After Deleting"<<std::endl;
    ht.Display();
    std::cout<< ht.search(21)<<std::endl;

   
}