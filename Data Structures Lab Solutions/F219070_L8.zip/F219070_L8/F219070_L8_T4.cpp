#include <iostream>
using namespace std;

//creating a node
struct Node{
	int data;
	Node *prev, *next;

};

class DEqueue
{
	Node* front;
	Node* rear;
	int size;

public:

	DEqueue()	{
		front = NULL;
        rear = NULL;
		size = 0;
	}
	//dequeue Methods
	void push_front(int data){
		//creating new node
	Node* newNode = new Node;
     newNode->data = data;
     newNode->prev = newNode->next = NULL;
	if (newNode == NULL)
		cout << "OverFlow\n";
	else	{
		if (front == NULL)
			rear = front = newNode;
		else
		{
			newNode->next = front;
			front->prev = newNode;
			front = newNode;
		}

		size++;
	}
}

	void push_back(int data){
	Node* newNode = new Node;
     newNode->data = data;
     newNode->prev = newNode->next = NULL;
	if (newNode == NULL)
		cout << "OverFlow\n";
	else	{
		if (rear == NULL)
			front = rear = newNode;
		else{
			newNode->prev = rear;
			rear->next = newNode;
			rear = newNode;
		}

		size++;
	}
}
	void pop_front(){
	if (isempty())
		cout << "UnderFlow\n";

	else{
		Node* temp = front;
		front = front->next;

		if (front == NULL)
			rear = NULL;
		else
			front->prev = NULL;
		delete temp;
        temp =NULL;
		size--;
	}
}
	void pop_rear(){
	if (isempty())
		cout << "UnderFlow\n";

	else{
		Node* temp = rear;
		rear = rear->prev;

		if (rear == NULL)
			front = NULL;
		else
			rear->next = NULL;
		delete temp;
        temp =NULL;

		size--;
	}
}
	int getFront(){
	if (isempty())
		return -1;
	return front->data;
    }
	int getRear();
	bool isempty(){
	return (front == NULL);
    }
};
int DEqueue::getRear(){
	if (isempty())
		return -1;
	return rear->data;
}

int main(){
    DEqueue q;
    cout<<"Pushing Data\n";
    q.push_front(2);
    q.push_front(5);
    q.push_front(6);
    q.push_front(2);
    q.push_front(45);
    q.push_front(223);
    q.push_back(454);
    q.push_back(435);
    q.push_back(445);
    q.pop_rear();
    cout<<"Getting Data: ";
    cout<<q.getFront()<<" ";
     q.pop_front();
    cout<<q.getFront()<<" ";
     q.pop_front();
    cout<<q.getFront()<<" ";

	return 0;
}
