#include<iostream>
using namespace std;
//Class Dequeue
class DEQueue
{
int* arr;
int front, rear;
int size;
public:
//constructor
DEQueue(int size = 5)
{
arr = new int[size];
front = -1;
rear = -1;
this->size = size;
}
//Dequeue Methods
void push_front(int val){
    if(front == -1)
    front = size-1;
    if(!full()){
    arr[front] = val;
    front--;
    }
    
}
void push_back(int val){
    if(rear == -1)
    rear = 0;
    if(full()){
    arr[rear] = val;
    rear++;
    }
}

void pop_front(){
    if(front == size-1)
    front = 0;
    front++;    

}

void pop_back(){
    if(rear == 0)
    rear = size-1;
    rear--;
}
int get_front(){
    return arr[front+1];
}
 
int get_back(){
    return arr[rear-1];
}
bool full(){
    if((front == 0 && rear == size-1)||front == rear+1)
    return true;
    return false;
}
bool isempty(){
    if(front == -1 && rear == -1)
    return true;  
    return false;
}
};

//Driver code
int main() {
DEQueue obj(10);
obj.push_front(1);
obj.push_front(2);
obj.push_front(3);
obj.push_front(4);
obj.push_front(5);
obj.push_back(10);
obj.push_back(9);
obj.push_back(8);
obj.push_back(7);
obj.push_back(6);
cout<<obj.get_front()<<" ";
obj.pop_front();
cout<<obj.get_front()<<" ";
obj.pop_front();
cout<<obj.get_front()<<" ";
obj.pop_front();
cout<<obj.get_front()<<" ";
obj.pop_front();
cout<<obj.get_front()<<" ";
obj.pop_front();

cout<<obj.get_back()<<" ";
obj.pop_back();
cout<<obj.get_back()<<" ";
obj.pop_back();
cout<<obj.get_back()<<" ";
obj.pop_back();
cout<<obj.get_back()<<" ";
obj.pop_back();
cout<<obj.get_back()<<" ";
obj.pop_back();


return 0;
}
