#include <iostream>
using namespace std;
//creating a node for queue having priority
struct Node {
	int value;
	int priority;
};

//creating a class of priority queue
class queu{
    Node *pr;
    int size ;
    int count; 
public:
//Constructor
    queu(int s = 10){
        pr = new Node[s];
        size = s;
        count = -1;
    }
    //for enquring data
    void enqueue(int value, int priority){
	this->count++;
	pr[count].value = value;
	pr[count].priority = priority;

    }

    //For dequeing data based on their priority
    int dequeue(){
	int higprio = -1;
	int index = -1;

	for (int i = 0; i < size; i++) {

        //finding the highes priority value index 
		if (higprio == pr[i].priority) {
			higprio = pr[i].priority;
			index = i;
		}
		else if (higprio < pr[i].priority) {
			higprio = pr[i].priority;
			index = i;
		}
	}
    //return the value
     int val = pr[index].value;
    //Arranging values and their priority
	for (int i = index; i < size; i++) {
		pr[i].value = pr[i + 1].value;
		pr[i].priority = pr[i + 1].priority;
	}
    
	size--;     
    return val;

}

};

int main()
{
	queu q(10);
    cout<<"Enqueing Data\n";
    q.enqueue(1,1);
    q.enqueue(2,34);
    q.enqueue(3,7);
    q.enqueue(4,4);
    q.enqueue(4,8);
    q.enqueue(55,6);
    q.enqueue(66,88);
    q.enqueue(44,99);
    q.enqueue(0,100);
    
  
    cout<<"Dequeing Data\n";

    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
    cout<<q.dequeue()<<" ";
}
