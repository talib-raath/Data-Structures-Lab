#include<iostream>
using namespace std;

//making a class ADT
class Graph{
    int **adm;
    int row,col;
    
public:
    //Constructor
    Graph(int r = 5,int c =5){
        row = r;
        col = c;
        //Allocating 2-d array
            adm = new int*[row];

            for (int i = 0;i<row;i++){
                *(adm+i) = new int[col];
            }

            for (int i=0;i<row;i++){
                for (int j = 0;j<col;j++){
                    adm[i][j] = 0;
                }
            }

    }

    //printing a matrix
    void print(){

    cout<<"Adjacent Matrix\n";
        cout<<"   ";
    for (int i=0;i<col;i++){
        cout<<i<<" ";
    }
        cout<<"\n  ";

    for (int i=0;i<col;i++)
        cout<<"--";
        cout<<"\n";

    //travesiong a matrix
    for (int i=0;i<row;i++){
        cout<<i<<" |";
        for (int j=0;j<col;j++){
            cout<<adm[i][j]<<" ";
        }
        cout<<"\n";
    }
    }

    void addedge(int i, int j){
        adm[i][j] = 1;
    }

    ~Graph(){
        for (int i = 0; i < row; i++)
    delete[] adm[i];
    delete[] adm;  
    }

};

int main(){
   
    //inserting a mtarix
    int n=0,x=0,y=0;
    cout<<"Enter Number of Vertices: ";
        cin>>n;
    Graph m(9,9);
    for (int i=0;i<n;i++){
        cout<<"Enter (x,y): ";
        cin>>x;
        cout<<"\t     ";
        cin>>y;
        m.addedge(x,y);
        m.addedge(y,x);
    }

    m.print();//Printing a adjnaacent matricx
}

